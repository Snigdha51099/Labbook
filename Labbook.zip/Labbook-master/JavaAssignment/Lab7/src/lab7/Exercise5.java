package lab7;

import java.util.ArrayList;
import java.util.Collections;

public class Exercise5 {

public Integer getSecondSmallestElement(int ar[]) {
		
		ArrayList<Integer> array=new ArrayList<>();
		for(int i=0;i<ar.length;i++)
		array.add(ar[i]);
		
		Collections.sort(array);
		return array.get(1);
		
		
	}
}
