package lab7;

import java.util.Arrays;
import java.util.Collections;

public class Exercise8 {

	static Integer[] modifyArray(Integer a[])
	{
		
			Arrays.sort(a,Collections.reverseOrder());
			return a;
	}
}
