package lab7;

import java.util.Arrays;

public class Exercise7 {

	public int[] getSorted(int a[]) {
	
		int b,c;
		for(int i=0;i<a.length;i++)
		{
			b=a[i];
			c=0;
			while(b!=0)
			{
				c=c*10+b%10;
				b=b/10;
			}
			a[i]=c;
		}
		Arrays.sort(a);
		
		return a;
	}
}
