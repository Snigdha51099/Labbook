package lab7;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

public class Exercise6 {

	static List<Integer> voterList(HashMap<Integer, LocalDate> hashMap){
		
		Set<Integer> set1=hashMap.keySet();
		
		
		List<Integer> list1=new ArrayList<Integer>();
		LocalDate localDate=null;
		LocalDate date=LocalDate.now();
		
		for(Integer i:set1) {
			localDate=hashMap.get(i);
			
			int year=Period.between(localDate, date).getYears();
			
			if(year>=18)
				list1.add(i);
		}
		return list1;
		
	}
}
