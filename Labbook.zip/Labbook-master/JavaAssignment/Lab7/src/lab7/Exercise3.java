package lab7;

import java.util.HashMap;

public class Exercise3 {

	public HashMap<Integer, Integer> getSquares(int arr[]){
		HashMap<Integer, Integer> hmap= new HashMap<Integer, Integer>();
		
		for (int a: arr) {
			hmap.put(a, a*a);
		}
		
		return hmap;
	}
}
