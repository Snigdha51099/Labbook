package lab3;

import java.util.HashMap;

public class Exercise4 {

	public HashMap<Character, Integer> countCharacter(char c[]){
		
		HashMap<Character, Integer> s = new HashMap<Character, Integer>();
		for( char character : c ) {
			if (s.containsKey(character)) {
				s.put(character, s.get(character)+1);
			}
			else {
			s.put(character, 1);
			}
		}
		return s;		
	}
}
