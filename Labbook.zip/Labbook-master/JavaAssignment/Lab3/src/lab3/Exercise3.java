package lab3;

import java.util.Arrays;

public class Exercise3 {

	public int[] getSorted(int arr[],int size) {
		String arr1[]= new String[size];
		for(int i=0;i<size;i++) {
			arr1[i]= Integer.toString(arr[i]);
			StringBuffer sbf = new StringBuffer(arr[i]);
			sbf.reverse();
			arr[i]= Integer.parseInt(arr1[i]);
		}
		Arrays.sort(arr);
		return arr;
	}
}
