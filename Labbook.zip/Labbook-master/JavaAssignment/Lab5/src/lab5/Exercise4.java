package lab5;

@SuppressWarnings("serial")
class myException extends RuntimeException{
	/**
	 * 
	 */

	public myException(String msg) {
		super(msg);
	}
}
public class Exercise4 
{
	
	public boolean isNameValid(String firstName, String lastName) throws myException {
		
		if ((firstName=="") && (lastName=="")){
			throw new myException("First name and last name is null");
		}
		
		return true;
		
	}
}
