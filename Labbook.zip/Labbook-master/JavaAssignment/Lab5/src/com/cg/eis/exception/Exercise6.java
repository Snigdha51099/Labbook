
package com.cg.eis.exception;

public class Exercise6 {

	public void checkSalary(int salary) {
		if (salary<3000)
			throw new EmployeeException("Salary is less than 3000");
		else {
			System.out.println("Valid Salary");
		}
	}
}
