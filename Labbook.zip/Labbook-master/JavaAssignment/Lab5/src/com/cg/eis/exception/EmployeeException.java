package com.cg.eis.exception;

@SuppressWarnings("serial")
public class EmployeeException extends RuntimeException{

	public EmployeeException(String msg) {
		super(msg);
	}
	
}
