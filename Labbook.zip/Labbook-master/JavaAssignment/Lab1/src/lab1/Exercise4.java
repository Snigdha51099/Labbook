package lab1;

public class Exercise4 {

	public boolean checkNumber(int n) {
		int a = 1;
		while(a<=n) {
			if (a==n) {
				return true;
			}
			a*=2;
		}
		return false;
	}
}
