package lab1;

public class Exercise3 {
	public boolean checkNumber(int number) {
		int ans= number % 10, m;
		while(number >0) {
			m= number % 10;
			if (m>ans) {
				return false;
			}
			ans=m;
			number=(int) number/10;
		}
		return true;
	}

}
