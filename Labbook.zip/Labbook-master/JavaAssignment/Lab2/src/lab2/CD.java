package lab2;

public class CD extends MediaItem {

	private String artist;
	private String genre;
	
	/**
	 * @param identifactionNo
	 * @param title
	 * @param numberOfCopies
	 * @param runTime
	 * @param artist
	 * @param genre
	 */
	public CD(int identifactionNo, String title, int numberOfCopies, int runTime, String artist, String genre) {
		super(identifactionNo, title, numberOfCopies, runTime);
		this.artist = artist;
		this.genre = genre;
	}

	/**
	 * @return the artist
	 */
	public String getArtist() {
		return artist;
	}

	/**
	 * @param artist the artist to set
	 */
	public void setArtist(String artist) {
		this.artist = artist;
	}

	/**
	 * @return the genre
	 */
	public String getGenre() {
		return genre;
	}

	/**
	 * @param genre the genre to set
	 */
	public void setGenre(String genre) {
		this.genre = genre;
	}
	

	@Override
	public String toString() {
		return "CD [artist=" + artist + ", genre=" + genre + "]";
	}

	@Override
	public void checkIn() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void checkOut() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addItem() {
		// TODO Auto-generated method stub
		
	}
	
	
}
