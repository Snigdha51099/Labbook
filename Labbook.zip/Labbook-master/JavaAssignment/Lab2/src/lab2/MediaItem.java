package lab2;

public abstract class MediaItem extends Item {
	private int runTime;
	public MediaItem(int identifactionNo, String title, int numberOfCopies, int runTime) {
		super(identifactionNo, title, numberOfCopies);
		// TODO Auto-generated constructor stub
		this.runTime=runTime;
	}
	public int getRunTime() {
		return runTime;
	}
	public void setRunTime(int runTime) {
		this.runTime = runTime;
	}
	@Override
	public String toString() {
		return "MediaItem [runTime=" + runTime + "]";
	}
	

}
