package lab2;

public class JournalPaper extends WrittenItem{

	private int publishedYear;
	public JournalPaper(int identifactionNo, String title, int numberOfCopies, String author,int publishedYear) {
		super(identifactionNo, title, numberOfCopies, author);
		this.setPublishedYear(publishedYear);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void checkIn() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void checkOut() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addItem() {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @return the publishedYear
	 */
	public int getPublishedYear() {
		return publishedYear;
	}

	/**
	 * @param publishedYear the publishedYear to set
	 */
	public void setPublishedYear(int publishedYear) {
		this.publishedYear = publishedYear;
	}

}
