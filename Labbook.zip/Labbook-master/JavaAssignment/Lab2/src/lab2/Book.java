package lab2;

public class Book extends WrittenItem{

	public Book(int identifactionNo, String title, int numberOfCopies, String author) {
		super(identifactionNo, title, numberOfCopies, author);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void checkIn() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void checkOut() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addItem() {
		// TODO Auto-generated method stub
		
	}
	

	

}
