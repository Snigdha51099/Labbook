package lab6;

public class Exercise3 {
	public static String getImage(String str) {
		StringBuffer str1=new StringBuffer();
		String s="";
		str1.append(str);
		str1.append("|");
		s=str1.reverse().toString();
		return str.concat(s);
	}

}
